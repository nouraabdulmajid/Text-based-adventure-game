package domain;

public class Bottom extends Clothing{

    public Bottom(String name) {
        super(name);
    }
}
