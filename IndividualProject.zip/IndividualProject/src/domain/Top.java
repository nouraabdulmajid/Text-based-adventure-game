package domain;

public class Top extends Clothing {

    public Top(String name) {

        super(name);
    }




}
