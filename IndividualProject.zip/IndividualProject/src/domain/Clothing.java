package domain;

public abstract class Clothing {
    protected String name;

    public Clothing(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    //think of an abstract method for later


}
