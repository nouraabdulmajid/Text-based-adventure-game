package domain;

public class SunProtection extends Clothing {

    public SunProtection(String name) {

        super(name);
    }

}
